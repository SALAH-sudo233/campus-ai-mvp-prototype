社团海报排版工具（PC 软件演示包 v0.9.4）
适用系统：macOS / Windows
说明：这是平台内置的 PC 软件安装包上传示例，真实学生发布时可上传 .dmg / .exe / .msi / .zip 包。